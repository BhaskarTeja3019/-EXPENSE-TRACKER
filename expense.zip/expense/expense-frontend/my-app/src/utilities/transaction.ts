interface frontend_trans{
    Date: string,
    Description: string,
    Amount: number,
    Currency:string
}


interface db_trans{
    id:number,
    date: string,
    description: string,
    amount: number,
    currency: string,
    inramount: number,
    ispresent:number,
}


export type { frontend_trans, db_trans };