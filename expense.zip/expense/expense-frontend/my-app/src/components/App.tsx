import React, { useState, useEffect } from 'react';
import './App.css';
import Header from './Header';
import Detail from './Detail';
import Transaction from './Transaction';
import Add_Modal from './Add_Modal';
import Upload_Model from './Upload_Modal';
import Edit_Modal from './Edit_Modal';
import Pagination from './Pagination';
import Loader from './Loader';
import Successful from './Successful_Modal';
import Unsuccessful from './Unsuccessful_Modal';

import axios from 'axios';
import { ToastContainer, toast, ToastContainerProps, Bounce } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import { db_trans, frontend_trans } from '../utilities/transaction';

const App: React.FC = () => {
  const [addButton, setAddButton] = useState<boolean>(false);
  const [uploadButton, setUploadButton] = useState<boolean>(false);
  const [editButton, setEditButton] = useState<{ clicked: boolean; id: number }>({ clicked: false, id: -1 });
  const [trans, setTrans] = useState<db_trans[]>([]);
  const [page, setPage] = useState(1);
  const [rowPerPage, setRowPerPage] = useState(10);
  const [dataUploaded, setDataUploaded] = useState(true);
  const [successful, setSuccessful] = useState(false);
  const [unsuccessful, setUnsuccessful] = useState(false);
  const [selectedTrans, setSelectedTrans] = useState<number[]>([]);
  const [allChecked, setAllChecked] = useState<boolean>(false);
  const [fileName, setFileName] = useState<string>("");
  const [progress, setProgress] = useState(0);


  const toastContainerProps: ToastContainerProps = {
    position: "top-left",
    autoClose: 1000,
    limit: 5,
    hideProgressBar: true,
    newestOnTop: false,
    closeOnClick: true,
    rtl: false,
    pauseOnFocusLoss: true,
    draggable: true,
    pauseOnHover: true,
    theme: "colored",
    transition: Bounce,
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = (await axios.get("http://localhost:8080/transaction/")).data.data;
        setTrans(result);
      } catch (error) {
        toast.error("Failed to fetch transactions");
      }
    };

    fetchData();
  }, []);

  return (
    <div className="container">
      <Header setAllChecked={setAllChecked} trans={trans} setTrans={setTrans} selectedTrans={selectedTrans} setSelectedTrans={setSelectedTrans} setAddClick={setAddButton} setUploadClick={setUploadButton} />
      <Detail setAllChecked={setAllChecked} allChecked={allChecked} trans={trans} rowPerPage={rowPerPage} page={page} selectedTrans={selectedTrans} setSelectedTrans={setSelectedTrans} />
      <Transaction selectedTrans={selectedTrans} setSelectedTrans={setSelectedTrans} trans={trans} setTrans={setTrans} setEditButton={setEditButton} page={page} rowPerPage={rowPerPage} />
      <ToastContainer {...toastContainerProps} />
      <Pagination page={page} setPage={setPage} rowPerPage={rowPerPage} setRowPerPage={setRowPerPage} trans={trans} />
      {addButton ? <Add_Modal setAddButton={setAddButton} setTrans={setTrans} /> : null}
      {uploadButton ? <Upload_Model setProgress={setProgress} setFileName={setFileName} setUploadButton={setUploadButton} setTrans={setTrans} setDataUploaded={setDataUploaded} setSuccessful={setSuccessful} setUnsuccessful={setUnsuccessful} /> : null}
      {successful ? <Successful fileName={fileName} setSuccessful={setSuccessful} /> : null}
      {unsuccessful ? <Unsuccessful fileName={fileName} setUnsuccessful={setUnsuccessful} /> : null}
      {editButton.clicked ? <Edit_Modal editButton={editButton} setEditButton={setEditButton} setTrans={setTrans} /> : null}
      {dataUploaded ? null : <Loader progress={progress} fileName={fileName} />}
    </div>
  );
}

export default App;
