import React from "react";
import "./Drop_Down.css";
import { db_trans } from "../utilities/transaction";

interface Drop_DownProps{
    setRowPerPage: React.Dispatch<React.SetStateAction<number>>,
    trans: db_trans[],
    setPage: React.Dispatch<React.SetStateAction<number>>,
    page:number
}

const Drop_Down: React.FC < Drop_DownProps >= ({setPage,setRowPerPage,page,trans}) =>{
  function handleChange(event:any) {
      setRowPerPage(parseInt(event.target.value)); 
      setPage(1);
      
  }

  return (
    <div className="dropdown">
      <p style={{ display: "inline" }}>Rows per Page</p>
      <select name="page-number" onChange={handleChange}>
        <option value="10">10</option>
        <option value="25">25</option>
        <option value="50">50</option>
      </select>
    </div>
  );
}


export default Drop_Down;
