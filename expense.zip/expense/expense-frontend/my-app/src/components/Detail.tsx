    import React from "react";
    import "./Detail.css"
    import { db_trans } from "../utilities/transaction";

    interface DetailProps{
        trans: db_trans[],
        rowPerPage: number,
        page: number,
        selectedTrans: number[],
        setSelectedTrans: React.Dispatch<React.SetStateAction<number[]>>,
        allChecked: boolean,
        setAllChecked:React.Dispatch<React.SetStateAction<boolean>>
    }


    const Detail=(props:any)=> {

        function handleClick(event: any) {
            
            if (event.target.checked) {
                const arr = props.trans.slice(props.rowPerPage * (props.page - 1), Math.min(props.trans.length, props.page * props.rowPerPage));
                props.setAllChecked(!props.allChecked);
                arr.map((obj: db_trans) => {   
                    
                    if (!props.selectedTrans.includes(obj.id)) {
                        props.selectedTrans.push(obj.id);
                    }
                    
                })

                props.setSelectedTrans(props.selectedTrans);
                
            }
            else {
                props.setAllChecked(!props.allChecked);
                const arr = props.trans.slice(props.rowPerPage * (props.page - 1), Math.min(props.trans.length, props.page * props.rowPerPage));

                let newArr = props.selectedTrans;
                arr.map((obj: db_trans) => {
                    newArr=newArr.filter((transId:number) => transId != obj.id);
                })
                
            
                props.setSelectedTrans(newArr);
            }
        }

        return (
            <div className="detail section">
                <div className="checkbox" ><input type="checkbox" checked={props.allChecked} onClick={handleClick}></input></div>
                <div className="date"><p>Date</p></div>
                <div className="description"><p>Description</p></div>
                <div className="org"><p>Original Amount</p></div>
                <div className="amount"><p>Amount in INR</p></div>
                <div className="action"></div>
            </div>
        )
    }

    export default Detail;