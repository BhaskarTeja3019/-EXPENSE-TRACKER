// src/components/Add_Modal.tsx
import React, { useState } from "react";
import { db_trans, frontend_trans } from '../utilities/transaction';
import axios from 'axios';
import "./Add_Modal.css"
import { toast,Bounce } from "react-toastify";
import currency_symbols from "./currency_code";

const MODAL_STYLES: React.CSSProperties = {
    position: 'fixed', // Ensure 'fixed' is a valid value
    width: '336px', // Strings with units are correct
    top: '50%', // Strings with units are correct
    left: '50%', // Strings with units are correct
    transform: 'translate(-50%, -50%)',
    backgroundColor: '#FFF',
    zIndex: 1000 // Numbers are valid here
};

const OVERLAY_STYLES: React.CSSProperties = {
    position: 'fixed', // Ensure 'fixed' is a valid value
    top: 0, // Numbers are valid here
    left: 0, // Numbers are valid here
    right: 0, // Numbers are valid here
    bottom: 0, // Numbers are valid here
    backgroundColor: 'rgba(0, 0, 0, .7)',
    zIndex: 1000 // Numbers are valid here
};



function convertDateFormat1(dateString:string) {

    var parts = dateString.split('-');
    var yyyy = parts[0];
    var mm = parts[1];
    var dd = parts[2];
    var ddMMyyyy = dd + '-' + mm + '-' + yyyy;
    return ddMMyyyy;

}

interface Add_ModalProps {
  setAddButton: React.Dispatch<React.SetStateAction<boolean>>;
  setTrans: React.Dispatch<React.SetStateAction<db_trans[]>>;
}

const Add_Modal: React.FC<Add_ModalProps> = ({ setAddButton, setTrans }) => {
  
    const [transaction, settransaction] = useState<frontend_trans>({Description:"",Currency:"AED",Amount:0,Date:""});
       
    function resetTransaction() {
        settransaction({Description:"",Currency:"AED",Amount:0,Date:""});
        setAddButton(false);
    }
    
    function updateTransaction(event:any) {
        const key = event.target.name;
        const value = event.target.value;
        settransaction({...transaction,[key]:value});
    }
    async function addTrans(){
        transaction.Date = convertDateFormat1(transaction.Date);
              
        try {
            let result = await axios.post("http://localhost:8080/transaction/", transaction);
            setTrans((prev) => [result.data.data, ...prev]);
            toast.success("Transaction Added", {
                position: "top-right",
                autoClose: 1000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "colored",
                transition: Bounce,
            });
        }
        catch (err:any) {
            console.log(err);
            toast.error(err.response.data.message);
        }
        resetTransaction();
           
    }  

    return (
        <div>
            <div style={OVERLAY_STYLES} />
            <div style={MODAL_STYLES} className="addmodal">
                <div className="addclose">
                    <p>Add Transaction</p>
                    <button onClick={() => { resetTransaction(); }}><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"   >
  <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8z"/>
</svg></button>
                </div>
                
                <div className="adddetails">
                    
                        <div className="additem1">
                            <input name="Description" onChange={updateTransaction} value={transaction.Description} type="text" placeholder="Transaction Description" required></input>
                        </div>
                        <div className="additem2">
                            <div>
                                <select name="Currency" onChange={updateTransaction}>
                                    {Object.keys(currency_symbols).map((obj)=> <option value={obj}>{obj}</option>)}
                                </select>
                            </div>
                            <div>
                                <input type="number"  placeholder="Original Amount" name="Amount" value={transaction.Amount?transaction.Amount:""} onChange={updateTransaction} required></input>
                            </div>
                        
                        </div>
                        <div className="additem3">
                            <input type="date"   name="Date" value={transaction.Date} onChange={updateTransaction} required></input>
                        </div>
                        
                    </div>
                    <div className="addbuttons">
                        
                        <div>
                            <button onClick={() => { resetTransaction();  }} className="addcancel">CANCEL</button>
                        </div>
                        <div>
                        <button className="addsave" onClick={() => { addTrans();}}>SAVE</button>
                        </div>
                        
                    </div>
               
                
            </div>
        </div>
        
    );
}

export default Add_Modal;
