import React from "react";
import "./Pagination.css"
import Jump_Buttons from "./Jump_Buttons";
import Drop_Down from "./Drop_Down";
import { db_trans } from "../utilities/transaction";


interface PaginationProps{
    page:number,
    setPage: React.Dispatch<React.SetStateAction<number>>;
    rowPerPage: number,
    setRowPerPage: React.Dispatch<React.SetStateAction<number>>,
    trans:db_trans[],
}

const Pagination:React.FC<PaginationProps>=({page,setPage,rowPerPage,setRowPerPage,trans})=> {
    return (
        <div className="pagination">
        <div><Drop_Down setRowPerPage={setRowPerPage} trans={trans} setPage={setPage} page={page}></Drop_Down></div>
        <div><Jump_Buttons page={page} setPage={setPage} trans={trans} rowPerPage={rowPerPage} /></div>    
        </div>
    );
};


export default Pagination;