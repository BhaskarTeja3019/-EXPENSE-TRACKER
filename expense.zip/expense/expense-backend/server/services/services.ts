import Transaction from "../types/transaction";
import db from "../database/database";
import axios, { AxiosResponse } from "axios";
import { emitProgress } from "../index";
interface CurrencyData {
    inr: {
        [key: string]: number;
    };
}

let currency_data: AxiosResponse<CurrencyData> | null = null;

const url = "http://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/inr.json";

const supportError = (currency: string) => `We currently don't support the currency: ${currency}`;
const apiError = "Error while fetching data from API";

async function getConversion(transaction: Transaction): Promise<number> {
    // if (currency_data) {
    //     const conversionRate = currency_data.data.inr[transaction.Currency.toLowerCase()];
    //     if (conversionRate) {
    //         return transaction.Amount / conversionRate;
    //     } else {
    //         throw { status: 500, message: supportError(transaction.Currency) };
    //     }
    // }

    try {
        currency_data = await axios.get<CurrencyData>(url);
        const conversionRate = currency_data.data.inr[transaction.Currency.toLowerCase()];
        if (conversionRate) {
            return transaction.Amount / conversionRate;
        } else {
            throw { status: 500, message: supportError(transaction.Currency) };
        }
    } catch (error) {
        if (axios.isAxiosError(error)) {
            throw { status: error.response?.status || 500, message: apiError };
        } else if (error instanceof Error) {
            throw { status: 500, message: error.message };
        } else {
            throw { status: 500, message: apiError };
        }
    }
}

async function getAllTransactions() {
    try {
        const result = await db.getAllTransactions();
        return result;
    } catch (error) {
        throw error;
    }
}

async function getTransactionById(id: number) {
    try {
        const result = await db.getTransactionById(id);
        return result;
    } catch (error) {
        throw error;
    }
}

async function addTransaction(transaction:Transaction) {
    
    //get the transaction inr_amount
    
    try {
        transaction.inrAmount = await getConversion(transaction);
        
        try {
            const addedTransaction =await db.addTransaction(transaction);
            return addedTransaction;
        }
        catch (error) {
            throw error;
        }
    }
    catch (error) {
        throw error;
    }
 
}

async function updateTransaction(transaction:Transaction, id:number) {

    //get the transaction inr_amount
    try {
        transaction.inrAmount = await getConversion(transaction);
        try {
            const updatedTransaction = await db.updateTransaction(transaction, id);
            return updatedTransaction;
        }
        catch (error) {
            throw error;
        }
    }
    catch (error) {
        throw error;
    }  

}

async function addCsvTransaction(transaction:Transaction[]) {
    //we will add these transaction in batch size
    
    
    for (let i = 0; i < transaction.length; i++){
        
        try {
            transaction[i].inrAmount = await getConversion(transaction[i]);
            const progress = Math.round((i / transaction.length) * 100);
            emitProgress(progress);
        }
        catch (error) {
            throw error;
        }
        
    }
   
    try {
        let addedCsvTransactions = await db.addBatchTransaction(transaction);
        return addedCsvTransactions;
    }
    catch (error) {
        throw error;
    }

    
}

async function deleteTransaction(id:number) {
   
    try {
        const result = await db.deleteTransaction(id);
        return result;
    }
    catch (error) {
        throw error;
    }

}


async function batchDelete(arr: number[]) {
    
    try {
        const result = await db.batchDelete(arr);
        return result;
    }
    catch (error) {
        throw error;
    }
}


export default { getAllTransactions,addCsvTransaction, getTransactionById, addTransaction, updateTransaction, deleteTransaction,batchDelete };
