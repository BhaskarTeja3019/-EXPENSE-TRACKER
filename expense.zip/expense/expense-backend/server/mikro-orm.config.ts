import { defineConfig, PostgreSqlDriver } from "@mikro-orm/postgresql";

export default defineConfig({
  dbName: "transaction",
  entities: ["./entities"],
  port: 5432,
  password:"Arya@9461",
  allowGlobalContext:true
});
