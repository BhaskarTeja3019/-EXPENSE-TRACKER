import { Request, Response } from 'express';

import services from '../services/services';
import message from './message';
import { CustomError,isCustomError } from "../types/Error";

import multer from "multer";
import csvParser from "csv-parser"
import fs from "fs";
import Transaction from '../types/transaction';
const upload = multer({ dest: "uploads/" });




async function getAllTransactions(req: Request, res: Response): Promise<void> {
    try {
        const transactions = await services.getAllTransactions();
        res.json({ status: message.ok, data: transactions });
    } catch (error) {
        if (isCustomError(error)) {
            res.status(error.status || 500).json({ status: message.failed, message: error.message });
        } else {
            res.status(500).json({ status: message.failed, message: 'An unexpected error occurred' });
        }
    }
}

async function getTransactionById(req:Request, res:Response) {

    const id = parseInt(req.params.id);

    try {
        const transaction = await services.getTransactionById(id);
        res.json({status:message.ok, data: transaction});
    }
    catch (error) {
        if (isCustomError(error)) {
            res.status(error.status || 500).json({ status: message.failed, message: error.message });
        } else {
            res.status(500).json({ status: message.failed, message: 'An unexpected error occurred' });
        }
    }
    
}

async function updateTransaction(req:Request, res:Response) {

    const transaction = req.body;
    const id = parseInt(req.params.id);
    
    try {
        const updatedTransaction = await services.updateTransaction(transaction,id);
        res.json({ status: message.updated, data: updatedTransaction });  

    }
    catch (error) {
        if (isCustomError(error)) {
            res.status(error.status || 500).json({ status: message.failed, message: error.message });
        } else {
            res.status(500).json({ status: message.failed, message: 'An unexpected error occurred' });
        }
    }

}


async function addTransaction(req:Request, res:Response) {
 

    const transaction = req.body;
    
    //if new transaction to be added has all details correct then insert the data into database by using add transaction service
    try {
        const addedTransaction = await services.addTransaction(transaction);
        res.json({ status:message.added, data: addedTransaction });    
    }
    catch (error) {
        if (isCustomError(error)) {
            res.status(error.status || 500).json({ status: message.failed, message: error.message });
        } else {
            res.status(500).json({ status: message.failed, message: 'An unexpected error occurred' });
        }
    }
    

}


async function addCsvTransaction(req: Request, res: Response) {
    // Ensure req.file exists
    if (!req.file) {
        return res.status(400).json({ status: message.failed, message: 'No file uploaded' });
    }

    const filePath = req.file.path;
    const result: Transaction[] = [];

    fs.createReadStream(filePath)
        .pipe(csvParser({
            mapHeaders: ({ header }) => header.trim().replace(/^\ufeff/, '') // Handle BOM
        }))
        .on("data", (row) => {
            result.push(row);
        })
        .on("end", async () => {
            try {
                const addedTransaction = await services.addCsvTransaction(result);
                res.json({ status: message.csvUploaded, data: addedTransaction });
            } catch (error) {
                if (isCustomError(error)) {
                    res.status(error.status || 500).json({ status: message.failed, message: error.message });
                } else {
                    res.status(500).json({ status: message.failed, message: 'An unexpected error occurred' });
                }
            }
        })
        .on("error", (error) => {
            // Handle any errors that occur during CSV parsing
            res.status(500).json({ status: message.failed, message: 'Error parsing CSV file' });
        });
}


async function deleteTransaction(req:Request, res:Response) {
    const id = parseInt(req.params.id);
    
    //check if the data corresponding to this id exists in my db
    try {
        const result=await services.deleteTransaction(id);
        res.json({ status: message.deleted, message: result });
    }
    catch (error) {
        if (isCustomError(error)) {
            res.status(error.status || 500).json({ status: message.failed, message: error.message });
        } else {
            res.status(500).json({ status: message.failed, message: 'An unexpected error occurred' });
        }
    }
    
}


async function batchDelete(req:Request,res:Response) {
    let arr = req.body;
    if (req.body.selectedTrans) {
        arr = req.body.selectedTrans;
    }

    try {
        const result = await services.batchDelete(arr);
        res.json({ status: message.deleted, message: result });
    }
    catch (error) {
        if (isCustomError(error)) {
            res.status(error.status || 500).json({ status: message.failed, message: error.message });
        } else {
            res.status(500).json({ status: message.failed, message: 'An unexpected error occurred' });
        }
    }
}


export default { getAllTransactions,addCsvTransaction, getTransactionById, addTransaction, updateTransaction, deleteTransaction,batchDelete };