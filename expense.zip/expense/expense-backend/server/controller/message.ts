const message = {
    ok: "OK",
    failed: "Failed",
    added: "Transaction Added",
    csvUploaded: "CSV Uploaded",
    updated: "Transaction Updated",
    deleted:"Transaction Deleted",
}


export default message;