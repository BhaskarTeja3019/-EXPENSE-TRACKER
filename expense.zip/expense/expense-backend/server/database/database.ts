import Transaction from "../types/transaction";
import pg from "pg";
import dbError from "./db_errors";
import { MikroORM } from "@mikro-orm/core";
import { transaction } from "../entities/expense";
import { CustomError, isCustomError } from "../types/Error";

import { em } from "../index";
const db = new pg.Client({
  user: "postgres",
  host: "localhost",
  database: "transaction",
  password: "",
  port: 5432,
});
db.connect();

async function getAllTransactions() {
  try {
    const transactions = await em.find(
      transaction,
      { ispresent: 1 },
      { orderBy: { id: "desc" } }
    );
    return transactions;
  } catch (error) {
    console.error(dbError.fetch, error);
    throw { status: 500, message: dbError.fetch };
  }
}

async function getTransactionById(id: number) {
  try {
    const result = await em.findOne(transaction, { id, ispresent: 1 });

    if (result) {
      return result;
    } else {
      throw { status: 400, message: dbError.id(id) };
    }
  } catch (error) {
    console.log(dbError.fetch, error);

    if (isCustomError(error)) {
      throw error;
    } else {
      throw { status: 500, message: dbError.fetch };
    }
  }
}

async function addTransaction(transactionData: Transaction) {
  
  try {
        const result = em.create(transaction, {
            date: transactionData.Date,
            description: transactionData.Description,
            amount: transactionData.Amount,
            currency: transactionData.Currency,
            inramount: transactionData.inrAmount?transactionData.inrAmount:0,
            ispresent:1
        });

        await em.persistAndFlush(result);
        return result;
  }
  catch (error) {
    console.error(dbError.insert, error);
    throw { status: 500, message: dbError.insert };
  }
    
}

async function addBatchTransaction(transactionData: Transaction[]) {

  try {
      const result = transactionData.map((obj) => {
          const t = new transaction(
              obj.Date,
              obj.Description,
              obj.Amount,
              obj.Currency,
              obj.inrAmount ? obj.inrAmount : 0,
          )
          em.persist(t);
          return t;
      });
    await em.flush();
    return result;
  }
  catch (error) {
    console.log(dbError.insert, error);
    throw { status: 500, message: dbError.insert };
  }
    
}

async function updateTransaction(transactionData: Transaction, id: number) {
   
  
    try {
      
        const result = await em.findOne(transaction, { id, ispresent: 1 });

        if (!result) {
            throw { status: 400, message: dbError.id(id) };
        }
    
        result.date= transactionData.Date,
        result.description= transactionData.Description,
        result.amount= transactionData.Amount,
        result.currency= transactionData.Currency,
        result.inramount= transactionData.inrAmount?transactionData.inrAmount:0,
        result.ispresent=1
        
    
        
        await em.persistAndFlush(result);
        return result;
        
    } catch (error) {
      console.error(dbError.update, error);
  
      if (isCustomError(error)) {
        throw error;
      } else {
        throw { status: 500, message: dbError.update };
      }
    }
}

async function deleteTransaction(id: number) {

  
    try {
      
      const result = await em.findOne(transaction, { id, ispresent: 1 });
  
      if (!result) {
        throw { status: 400, message: dbError.id(id) };
      }
  
      
      result.ispresent = 0;
      await em.persistAndFlush(result);
  
      return { status: "Deleted Successfully" };
        
    } catch (error) {

      console.error(dbError.delete, error);
  
      if (isCustomError(error)) {
        throw error;
      } else {
        throw { status: 500, message: dbError.delete };
      }
        
    }
}



async function batchDelete(arr: number[]) {
  try {
   
    const results = await em.find(transaction, { id: { $in: arr }, ispresent: 1 });

    if (results.length !== arr.length) {
      const fetchedIds = results.map(result => result.id);
      const missingIds = arr.filter(id => !fetchedIds.includes(id));
      throw { status: 400, message: dbError.id(missingIds[0]) };
    }

    
    results.forEach(result => {
      result.ispresent = 0;
    });
      
    await em.persistAndFlush(results);
    return { status: "Deleted Successfully" };
      
  } catch (error) {
      
    console.error(dbError.delete, error);
    if (isCustomError(error)) {
        throw error;
    } else {
        throw { status: 500, message: dbError.delete };
    }
  }
}




export default {
  getAllTransactions,
  getTransactionById,
  addTransaction,
  addBatchTransaction,
  updateTransaction,
  deleteTransaction,
  batchDelete
};
