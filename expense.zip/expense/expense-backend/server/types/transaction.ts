interface Transaction{
    Date: string,
    Description: string,
    Currency: string,
    Amount: number,
    inrAmount?:number,
}


export default Transaction;