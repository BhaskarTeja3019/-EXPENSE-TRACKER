interface CustomError {
    status?: number;
    message: string;
}
function isCustomError(error: any): error is CustomError {
    return error && typeof error.message === 'string';
}


export  { CustomError, isCustomError };