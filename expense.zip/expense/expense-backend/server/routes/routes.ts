import express from "express";
import controller from "../controller/controller";

import {validateRow, validateTransaction,handleValidationError } from "../middleware/validator";

const router = express.Router();


import multer from "multer";
import csvParser from "csv-parser"
import fs from "fs";
const upload = multer({ dest: "../controller/uploads/"});



router.get("/", controller.getAllTransactions);

router.get("/:id", controller.getTransactionById);


router.post("/",validateTransaction,handleValidationError, controller.addTransaction);

router.put("/:id",validateTransaction,handleValidationError, controller.updateTransaction);

router.post("/csv", upload.single("csv"),validateRow, controller.addCsvTransaction);

router.delete("/bulkDel", controller.batchDelete);

router.delete("/:id", controller.deleteTransaction);




export default router;

