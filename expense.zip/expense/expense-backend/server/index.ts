import express from 'express';
import router from './routes/routes';
import bodyParser from 'body-parser';
import cors from "cors";
import { MikroORM, EntityManager } from '@mikro-orm/postgresql';
import config from "./mikro-orm.config"
import http from 'http';
import { Server } from 'socket.io';

const app = express();
const server = http.createServer(app);


const port = 8080;
app.use(cors());
app.use(bodyParser.json());

const io = new Server(server, {
  cors: {
    origin: '*',
  },
});


io.on('connection', (socket) => {
  console.log('Client connected');

  socket.on('disconnect', () => {
    console.log('Client disconnected');
  });
});


export const emitProgress = (progress: number) => {
  io.emit('insertionProgress', { progress });
};


app.get('/', (req, res) => {
  res.send('Hello, TypeScript with Express!');
});

// app.listen(port, () => {
//   console.log(`Server is running on http://localhost:${port}`);
// });

export let em: EntityManager;
const initORM = async () => {
  const orm = await MikroORM.init(config);
  em = orm.em;
};
initORM();


app.use("/transaction", router);

server.listen(8080, () => {
  console.log('Server started on http://localhost:8080');
});