import { Entity, PrimaryKey, Property } from "@mikro-orm/core";
@Entity()
export class transaction {

  @Property()
    date: string;
    
  @Property()
    description: string;
    
  @Property()
    amount: number;
    
  @Property()
    currency: string;
    
  
  @PrimaryKey()
    id!: number;
    
    
  @Property()
    inramount: number;
    
  @Property({ default: 1, fieldName: 'ispresent' })
    ispresent: number;
    
  constructor(
    date: string,
    description: string,
    amount: number,
    currency: string,
    inramount: number
  ) {
    this.date = date;
    this.description = description;
    this.amount = amount;
    this.currency = currency;
    this.inramount = inramount;
    this.ispresent = 1;
  }
}


